<?php



require_once('dbconnect.php');


$email = $_POST['email'];
$pwd = $_POST['pwd'];





$my_query = "";


$my_query= "select * from Users where email = '$email' and pwd = '$pwd'"; 

$result = mysqli_query($connection, $my_query);

if($result->num_rows > 0)
{
	
$my_query= "select * from details where email ='$email'";
	
$result=mysqli_query($connection,$my_query);
$json_array=array();
while($row =mysqli_fetch_assoc($result))
{
$json_array[]=$row;
}
echo json_encode($json_array);
}
else
{
echo "no data";
}	
   
     
?>