<?php



require_once('dbconnect.php');

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$pwd = $_POST['pwd'];
echo "<br>";


$my_query = "";
$my_query = "INSERT INTO Users (fname, lname, email, pwd) VALUES ('$fname', '$lname', '$email', '$pwd' )";

 if($connection->query($my_query)=== TRUE){
		 //echo "New record created successfully";
		 header('location:call.html');

		 }
			 else
			 {
				 echo "Error:" .$sql. "<br>". $conn->error;
			 }
		

   
    
   


?>