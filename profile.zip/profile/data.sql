-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 10, 2018 at 03:08 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

DROP TABLE IF EXISTS `details`;
CREATE TABLE IF NOT EXISTS `details` (
  `Username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`Username`, `email`, `contact`, `address`) VALUES
('lk', 'lk@lk', '876', 'vfxcc'),
('resh', 'resh@banu', '2677', 'hbhds'),
('sd', 'sd@sd', '267773', 'ghdhdh'),
('sd', 'sd@sd', '267773', 'ghdhdh'),
('kl', 'kl@kl', '567', 'dfgg'),
('mn', 'mn@mn', '667', 'mnmn'),
('bv', 'bv@bv', '765899', 'gghbn');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pwd` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `pwd`) VALUES
(2, 'resh', 'banu', 'aa@gg', 'aagg'),
(3, 'rr', 'ee', 'rr@ee', 'rree'),
(4, 'd', 'f', 'df@as', 'dfas'),
(5, 'reshu', 'shami', 'shami@banu', 'banu'),
(6, 'df', 'df', 'as@gh', 'asgh'),
(7, 'res', 'hma', 'res@hma', 'reshma'),
(8, 're', 'sd', 're@sd', 'resd'),
(9, 'rt', 'yu', 'rt@yu', 'rtyu'),
(10, 'yu', 'io', 'yu@io', 'yuio'),
(11, 'df', 'jk', 'df@jk', 'dfjk'),
(12, 'we', 'er', 'we@er', 'weer'),
(13, '', '', '', ''),
(14, '', '', '', ''),
(15, 'ed', 'ed', 'ed@ed', 'eded'),
(16, 'xx', 'zz', 'xx@zz', 'xxzz'),
(17, 'lk', 'lk', 'lk@lk', 'lklk'),
(18, 'resh', 'banu', 'resh@banu', 'resh'),
(19, '', '', '', ''),
(20, 'kl', 'kl', 'kl@kl', 'klkl'),
(21, 'MN', 'MN', 'mn@mn', 'mnmn'),
(22, 'bv', 'bv', 'bv@bv', 'bvbv');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
