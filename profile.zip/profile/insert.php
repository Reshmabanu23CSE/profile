<?php



require_once('dbconnect.php');

$Username = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$address = $_POST['address'];
$sql="INSERT INTO details(Username,email,contact, address) values ('$Username', '$email', '$contact', '$address')";
		 
		 if($connection->query($sql)=== TRUE){
		 echo "New record created successfully";
		 //header('location:call.html');

		 }
			 else
			 {
				 echo "Error:" .$sql. "<br>". $connection->error;
			 }
    
    
    
    ?>

